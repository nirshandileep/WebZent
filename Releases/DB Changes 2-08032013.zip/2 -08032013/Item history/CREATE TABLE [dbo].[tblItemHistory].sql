/****** Object:  Table [dbo].[tblItemHistory]    Script Date: 05/11/2013 14:54:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tblItemHistory](
	[HistoryId] [bigint] IDENTITY(1,1) NOT NULL,
	[ItemId] [int] NOT NULL,
	[Description] [varchar](100) NOT NULL,
	[Qty] [int] NOT NULL,
	[Cost] [money] NOT NULL,
	[SellingPrice] [money] NOT NULL,
	[Date] [datetime] NOT NULL,
	[UserId] [int] NULL,
	[RefId] [bigint] NULL,
	[HistoryTypeId] [int] NOT NULL,
 CONSTRAINT [PK_tblItemHistory] PRIMARY KEY CLUSTERED 
(
	[HistoryId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[tblItemHistory]  WITH CHECK ADD  CONSTRAINT [FK_tblItemHistory_tblItemHistoryTypes] FOREIGN KEY([HistoryTypeId])
REFERENCES [dbo].[tblItemHistoryTypes] ([HistoryTypeId])
GO

ALTER TABLE [dbo].[tblItemHistory] CHECK CONSTRAINT [FK_tblItemHistory_tblItemHistoryTypes]
GO

ALTER TABLE [dbo].[tblItemHistory]  WITH CHECK ADD  CONSTRAINT [FK_tblItemHistory_tblItems] FOREIGN KEY([ItemId])
REFERENCES [dbo].[tblItems] ([ItemId])
GO

ALTER TABLE [dbo].[tblItemHistory] CHECK CONSTRAINT [FK_tblItemHistory_tblItems]
GO

ALTER TABLE [dbo].[tblItemHistory]  WITH CHECK ADD  CONSTRAINT [FK_tblItemHistory_tblUsers] FOREIGN KEY([UserId])
REFERENCES [dbo].[tblUsers] ([UserId])
GO

ALTER TABLE [dbo].[tblItemHistory] CHECK CONSTRAINT [FK_tblItemHistory_tblUsers]
GO


